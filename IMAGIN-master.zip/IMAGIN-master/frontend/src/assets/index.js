import download from "./download.png";
import logo from "./logo.svg";
import preview from "./preview.webp";

export { download, logo, preview };
